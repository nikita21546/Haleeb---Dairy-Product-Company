CREATE DATABASE  IF NOT EXISTS `haleeb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `haleeb`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: haleeb
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `admin_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `ph_no` varchar(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `contact_UNIQUE` (`ph_no`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'Melisandra Fleetwood','3252262931','mfleetwood0','sWMUciw'),(2,'Mariana Hambly','9633045402','mhambly1','MSdzZqTZb'),(3,'Em Itskovitz','5472941684','eitskovitz2','sv1Pwr6Z'),(4,'Rodolph Loweth','7212303958','rloweth3','nx0QtKt9Zi'),(5,'Ingrim Rivaland','3721866644','irivaland4','uidy2DUj8U'),(6,'Josh Jaycox','4015951202','jjaycox5','vtxggf917YIn'),(7,'Carter Josephi','1248219318','cjosephi6','onPrXlbM'),(8,'Marten Rhubottom','5537963579','mrhubottom7','IsOqG5NlZC'),(9,'Hetty Brauner','8981144092','hbrauner8','lywqasAx'),(10,'Kingsly Stearndale','3224116520','kstearndale9','EhYHzpMzbs'),(11,'Alleyn Strowthers','1893172578','astrowthersa','X9CH6WE'),(12,'Ruthy Lean','2785296113','rleanb','3jzVaoMs5TZo'),(13,'Teresita Dunseath','9915084208','tdunseathc','XkAqXqs'),(14,'Fredric Harris','6427914057','fharrisd','nDdB3GKDo'),(15,'Teodoro Brixham','1133081789','tbrixhame','mrAZaG'),(16,'Coriss Shilvock','2483342816','cshilvockf','kRqyLAvU'),(17,'Cordi Stubbins','6417091959','cstubbinsg','RcVwS9'),(18,'Kipper Beck','6254977811','kbeckh','Ji76ZNr2J'),(19,'Carmel Tarrant','7155465232','ctarranti','c6yZm4XtdV'),(20,'Jedidiah Rennicks','3822047561','jrennicksj','PdmNNyAXfT'),(21,'Gard Conkey','1004012672','gconkeyk','VFQtse49'),(22,'Merilee Eannetta','7369414979','meannettal','ZOjpf3mnG'),(23,'Jaime Deare','4076778576','jdearem','WuYYp04'),(24,'Thea Ulyet','7582591836','tulyetn','ZM01rtn'),(25,'Vasilis Rizzone','8684901665','vrizzoneo','OwmCz3Z'),(26,'Sheree Biermatowicz','3219457513','sbiermatowiczp','DjyoPp'),(27,'Lissy McKendo','5284958600','lmckendoq','kEY5yzLI0'),(28,'Tedi Simondson','4317804233','tsimondsonr','APC78uto7aK'),(29,'Robbi Peters','2241045158','rpeterss','T1srF7L'),(30,'Nevsa Chilcott','5569883447','nchilcottt','VB0mMJRi'),(31,'Diane-marie Bims','9137950507','dbimsu','bA5Suo'),(32,'Frederick Nussey','4079036732','fnusseyv','ury605Jxprbj'),(33,'Willie Beardshaw','7922182453','wbeardshaww','KBTWNdJjwS1'),(34,'Kelcy Lehon','3494488614','klehonx','awb6xfD792K4'),(35,'Barty Stripling','7682713224','bstriplingy','fbPpcWSgT'),(36,'Marylee Haigh','3581872700','mhaighz','c5nq4R'),(37,'Kalinda Zanussii','4396786562','kzanussii10','YUAN1PdPoa'),(38,'Andrej Molfino','7631030004','amolfino11','MWi2Tmrf'),(39,'Hiram Currington','3495600598','hcurrington12','6d1dDmCh'),(40,'Fredrika Mochar','2575924643','fmochar13','o9h51Jt4qK'),(41,'Albina Abrahamsohn','9971985039','aabrahamsohn14','w74R3wCikPE'),(42,'Gertrud Dronsfield','3576360695','gdronsfield15','JauDZfVViu'),(43,'Leon Stinton','3188531448','lstinton16','EPe522'),(44,'Alverta Waything','7007142028','awaything17','JteZl8GG'),(45,'Tabitha Halliday','6015064295','thalliday18','rTPNMnve'),(46,'Nealson Clitsome','9098070853','nclitsome19','XXq1zdpa'),(47,'Patin Doggrell','9422426594','pdoggrell1a','KNhw7OHEdUH'),(48,'Zulema Pladen','1512357401','zpladen1b','Nj1ECOj'),(49,'Guglielma Eves','4593807757','geves1c','YtxoMzjt'),(50,'Ferd McLarty','3676114464','fmclarty1d','4w1XVrryr8'),(51,'Coriss Grouen','3725984003','cgrouen1e','xGtDVU'),(52,'Brandy Borgars','1177840733','bborgars1f','Sf7YNYLnl'),(53,'Glenna Adriaan','4114803007','gadriaan1g','SiekNxIz'),(54,'Boyd Rahlof','5512917323','brahlof1h','KmunpC3jRF'),(55,'Link Mc Harg','4559650420','lmc1i','sU3F9RA8A'),(56,'Thain Ancell','2099064612','tancell1j','Pu2kOPjrW'),(57,'Gerrie Georgius','8639612067','ggeorgius1k','i4ica2ZEgSJW'),(58,'Edgardo Spatig','2503829155','espatig1l','EmgBLHgxKExu'),(59,'Ichabod Gynni','9229294793','igynni1m','knjLPuBb'),(60,'Valentin Bradden','6995489382','vbradden1n','xEG6Bi1'),(61,'Courtney Salkeld','5718517742','csalkeld1o','QLC6XUpqZ'),(62,'Ciel Furze','6059119785','cfurze1p','RtGKXTesH'),(63,'Lilas Sylvaine','5868342892','lsylvaine1q','UyW4Zs4g7'),(64,'Dom Figure','2441139978','dfigure1r','ofEuve4upaZP'),(65,'Jeanna Kacheller','8418756383','jkacheller1s','EM70JjRt7Hc'),(66,'Hali Drepp','7195295891','hdrepp1t','oGlSZ51zb'),(67,'Iolanthe Brabban','2183239406','ibrabban1u','ormwRRCj'),(68,'Tonye Waterfall','2028184270','twaterfall1v','Ac0VhdZmz8Z'),(69,'Ofilia Yude','4069066049','oyude1w','g7sUsDNE5eSM'),(70,'Eba Morford','6146521220','emorford1x','MFFGYs9'),(71,'Lee Simonnet','3126343603','lsimonnet1y','iV7R6vN3g'),(72,'Vidovik Albrooke','3029366809','valbrooke1z','JZYm9PkrvTQ'),(73,'Donnajean Samuel','7958753162','dsamuel20','BYs4NCSsTv'),(74,'Mair Voase','4196368684','mvoase21','D88r9qSff'),(75,'Gussi Bromwich','5547929733','gbromwich22','3ADq5S46L8'),(76,'Dredi Josipovitz','4844213685','djosipovitz23','2kF8jZkkZ'),(77,'Red Craghead','3115895505','rcraghead24','Dm8HSvWc'),(78,'Dania Ianiello','7467438779','dianiello25','gNOG3nJps8'),(79,'Alie Roundtree','9955897910','aroundtree26','qIWXvndN7y'),(80,'Lily Benedite','5049282910','lbenedite27','tg7THZM'),(81,'Clarie Mary','7712412153','cmary28','FqpchS5'),(82,'Roderich Iacobo','1047130525','riacobo29','5apzAGZ2kE'),(83,'Lauree Fahy','7498304842','lfahy2a','1vBZM7yZHGY'),(84,'Shayne Priddle','3617776098','spriddle2b','2L0O9INmgI'),(85,'Marj McKeaney','7122658434','mmckeaney2c','JfgMvJ9zb'),(86,'Stanleigh De Roberto','3151956633','sde2d','xwOab4qDsWu'),(87,'Cchaddie Golling','2518577270','cgolling2e','FkV7pX59'),(88,'Farlie Larrad','8461063974','flarrad2f','gxcItH'),(89,'Fernandina Fealy','6173780831','ffealy2g','eIGBPL'),(90,'Silva Clementson','9771095548','sclementson2h','Qbv3G4vrm'),(91,'Dudley Mann','3405563355','dmann2i','8buFEaZfU'),(92,'Cinderella Piburn','5534174676','cpiburn2j','hrytU87HXzvK'),(93,'Patrizio Asch','6154856648','pasch2k','RbgWAfnd'),(94,'Amargo Goldsberry','8133089796','agoldsberry2l','KI3bPDv3'),(95,'Desmund Elvish','4008342917','delvish2m','0uorbJCD6va'),(96,'Kathie Benka','3347521911','kbenka2n','gLcVq9oZ'),(97,'Godfrey Eshelby','5133689880','geshelby2o','xIdmSXcrx7mq'),(98,'Even Cockerham','5646641917','ecockerham2p','JOWV5v9'),(99,'Augustus Butson','7666222951','abutson2q','NATIwFOUYL'),(100,'Arnuad Dawe','4207555292','adawe2r','3IGOm56TE');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-24 23:04:34
