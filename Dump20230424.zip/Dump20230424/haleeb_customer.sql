CREATE DATABASE  IF NOT EXISTS `haleeb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `haleeb`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: haleeb
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'\"John Doe\"','johndoe@example.com','johndoe','password1'),(2,'\"Jane Doe\"','janedoe@example.com','janedoe','password2'),(3,'\"Jim Smith\"','jimsmith@example.com','jimsmith','password3'),(4,'\"Alex Johnson\"','alexjohnson@example.com','alexjohnson','password4'),(5,'\"Emma Wilson\"','emmawilson@example.com','emmawilson','password5'),(6,'\"Michael Brown\"','michaelbrown@example.com','michaelbrown','password6'),(7,'\"Emily Davis\"','emilydavis@example.com','emilydavis','password7'),(8,'\"William Anderson\"','williamanderson@example.com','williamanderson','password8'),(9,'\"Sophia Jackson\"','sophiajackson@example.com','sophiajackson','password9'),(10,'\"Olivia Martinez\"','oliviamartinez@example.com','oliviamartinez','password10'),(11,'\"Ava Smith\"','avasmith@example.com','avasmith','password11'),(12,'\"Mia Wilson\"','miawilson@example.com','miawilson','password12'),(13,'\"Isabella Davis\"','isabelladavis@example.com','isabelladavis','password13'),(14,'\"Madison Johnson\"','madisonjohnson@example.com','madisonjohnson','password14'),(15,'\"Abigail Wilson\"','abigailwilson@example.com','abigailwilson','password15'),(16,'\"Elizabeth Brown\"','elizabethbrown@example.com','elizabethbrown','password16'),(17,'\"Evelyn Davis\"','evelyndavis@example.com','evelyndavis','password17'),(18,'\"Chloe Anderson\"','chloeanderson@example.com','chloeanderson','password18'),(19,'\"Avery Jackson\"','averyjackson@example.com','averyjackson','password19'),(20,'\"Ella Martinez\"','ellamartinez@example.com','ellamartinez','password20'),(21,'\"Aurora Smith\"','aurorasmith@example.com','aurorasmith','password21'),(22,'\"Scarlett Wilson\"','scarlettwilson@example.com','scarlettwilson','password22'),(23,'\"Natalie Davis\"','nataliedavis@example.com','nataliedavis','password23'),(24,'\"Addison Johnson\"','addisonjohnson@example.com','addisonjohnson','password24'),(25,'\"Aaliyah Wilson\"','aaliyahwilson@example.com','aaliyahwilson','password25'),(26,'\"Natalie Brown\"','nataliebrown@example.com','nataliebrown','password26'),(27,'\"Sofia Davis\"','sofiadavis@example.com','sofiadavis','password27'),(28,'\"Aubrey Anderson\"','aubreyanderson@example.com','aubreyanderson','password28'),(29,'\"Brooklyn Jackson\"','brooklynjackson@example.com','brooklynjackson','password29'),(30,'\"Bella Martinez\"','bellamartinez@example.com','bellamartinez','password30'),(32,'\"Avery Wilson\"','averywilson@example.com','averywilson','password32'),(40,'\"Daniel Anderson\"','danielanderson@example.com','danielanderson','password40'),(41,'\"Sophie Smith\"','sophiesmith@example.com','sophiesmith','password41'),(43,'\"William Jackson\"','williamjackson@example.com','williamjackson','password43'),(44,'\"James Wilson\"','jameswilson@example.com','jameswilson','password44'),(45,'\"Ethan Johnson\"','ethanjohnson@example.com','ethanjohnson','password45'),(46,'\"Charlotte Martinez\"','charlottemartinez@example.com','charlottemartinez','password46'),(47,'\"Michael Davis\"','michaeldavis@example.com','michaeldavis','password47'),(48,'\"Alexander Smith\"','alexandersmith@example.com','alexandersmith','password48'),(49,'\"Natalie Wilson\"','nataliewilson@example.com','nataliewilson','password49'),(50,'\"Ella Jackson\"','ellajackson@example.com','ellajackson','password50'),(51,'\"Liam Martinez\"','liammartinez@example.com','liammartinez','password51'),(52,'\"Chloe Smith\"','chloesmith@example.com','chloesmith','password52'),(53,'\"Mason Johnson\"','masonjohnson@example.com','masonjohnson','password53'),(54,'\"Ava Wilson\"','avawilson@example.com','avawilson','password54'),(55,'\"Olivia Davis\"','oliviadavis@example.com','oliviadavis','password55'),(56,'\"Jacob Smith\"','jacobsmith@example.com','jacobsmith','password56'),(57,'\"Isabelle Martinez\"','isabellemartinez@example.com','isabellemartinez','password57'),(58,'\"Mia Jackson\"','miajackson@example.com','miajackson','password58'),(60,'\"Emma Davis\"','emmadavis@example.com','emmadavis','password60'),(61,'\"Michael Martinez\"','michaelmartinez@example.com','michaelmartinez','password61'),(62,'\"Sophia Wilson\"','sophiawilson@example.com','sophiawilson','password62'),(63,'\"Emily Smith\"','emilysmith@example.com','emilysmith','password63'),(64,'\"Alexander Davis\"','alexanderdavis@example.com','alexanderdavis','password64'),(65,'\"Natalie Martinez\"','nataliemartinez@example.com','nataliemartinez','password65'),(66,'\"James Rodriguez\"','jamesrodriguez@example.com','jamesrodriguez','password66'),(67,'\"Noah Martinez\"','noahmartinez@example.com','noahmartinez','password67'),(68,'\"Liam Wilson\"','liamwilson@example.com','liamwilson','password68'),(69,'\"Ethan Davis\"','ethandavis@example.com','ethandavis','password69'),(70,'\"Ava Anderson\"','avaanderson@example.com','avaanderson','password70'),(72,'\"Isabella Smith\"','isabellasmith@example.com','isabellasmith','password72'),(73,'\"Emily Brown\"','emilybrown@example.com','emilybrown','password73'),(74,'\"Abigail Johnson\"','abigailjohnson@example.com','abigailjohnson','password74'),(75,'\"Avery Martinez\"','averymartinez@example.com','averymartinez','password75'),(76,'\"Ella Wilson\"','ellawilson@example.com','ellawilson','password76'),(77,'\"Madison Davis\"','madisondavis@example.com','madisondavis','password77'),(78,'\"Aria Anderson\"','ariaanderson@example.com','ariaanderson','password78'),(79,'\"Riley Jackson\"','rileyjackson@example.com','rileyjackson','password79'),(80,'\"Sofia Smith\"','sofiasmith@example.com','sofiasmith','password80'),(81,'\"Charlotte Brown\"','charlottebrown@example.com','charlottebrown','password81'),(82,'\"Harper Johnson\"','harperjohnson@example.com','harperjohnson','password82'),(83,'\"Evelyn Martinez\"','evelynmartinez@example.com','evelynmartinez','password83'),(84,'\"Abby Wilson\"','abbywilson@example.com','abbywilson','password84'),(85,'\"Aaliyah Davis\"','aaliyahdavis@example.com','aaliyahdavis','password85'),(86,'\"Arianna Anderson\"','ariannaanderson@example.com','ariannaanderson','password86'),(87,'\"Aurora Jackson\"','aurorajackson@example.com','aurorajackson','password87'),(88,'\"Genesis Smith\"','genesissmith@example.com','genesissmith','password88'),(89,'\"Brooklyn Brown\"','brooklynbrown@example.com','brooklynbrown','password89'),(90,'\"Natalie Johnson\"','nataliejohnson@example.com','nataliejohnson','password90'),(92,'\"Jacob Anderson\"','jacobanderson@example.com','jacobanderson','password92'),(93,'\"Sophie Brown\"','sophiebrown@example.com','sophiebrown','password93'),(94,'\"Mason Wilson\"','masonwilson@example.com','masonwilson','password94'),(95,'\"Avery Davis\"','averydavis@example.com','averydavis','password95'),(96,'\"Ethan Jackson\"','ethanjackson@example.com','ethanjackson','password96'),(98,'\"Natalie Smith\"','nataliesmith@example.com','nataliesmith','password98'),(99,'\"Mila Wilson\"','milawilson@example.com','milawilson','password99'),(100,'\"William Davis\"','williamdavis@example.com','williamdavis','password100');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `customer_AFTER_INSERT` AFTER INSERT ON `customer` FOR EACH ROW BEGIN
	insert into location(branch_id, address, ph_no) values (NEW.customer_id, "Address xx", FLOOR(RAND() * (5000000000 - 1000000000 + 1)) + 1000000000);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-24 23:04:35
