CREATE DATABASE  IF NOT EXISTS `haleeb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `haleeb`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: haleeb
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier` (
  `supplier_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `ph_no` varchar(10) NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `b_no` int NOT NULL,
  PRIMARY KEY (`supplier_id`),
  UNIQUE KEY `ph_no_UNIQUE` (`ph_no`),
  UNIQUE KEY `address_UNIQUE` (`address`),
  KEY `branch_id_idx` (`b_no`),
  CONSTRAINT `branch_id` FOREIGN KEY (`b_no`) REFERENCES `location` (`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (1,'\"Lucky Carlisi\"','1967214573','\"411 1st Circle\"','lcarlisi0@histats.com',40),(2,'\"Joni Voice\"','1939033538','\"959 Hudson Hill\"','jvoice1@dedecms.com',66),(3,'\"Tillie Banke\"','1010658283','\"7 Bonner Street\"','tbanke2@gnu.org',45),(4,'\"Peyter Cavilla\"','1312355016','\"94 Independence Center\"','pcavilla3@springer.com',17),(5,'\"Alexio Cossons\"','1699790741','\"954 Clyde Gallagher Point\"','acossons4@imdb.com',49),(6,'\"Marisa Cyson\"','1400965461','\"45 Mesta Lane\"','mcyson5@privacy.gov.au',35),(7,'\"Garland Lamort\"','1300092840','\"058 Melody Crossing\"','glamort6@51.la',84),(8,'\"Adriena Addicott\"','1928279787','\"7 Dennis Park\"','aaddicott7@seattletimes.com',4),(9,'\"Leanna Pittendreigh\"','1615157315','\"8280 American Street\"','lpittendreigh8@princeton.edu',33),(10,'\"Dionis Elcock\"','1209714051','\"00 Darwin Terrace\"','delcock9@sciencedaily.com',9),(11,'\"Aila Mazonowicz\"','1998708971','\"5436 Reinke Circle\"','amazonowicza@vk.com',43),(12,'\"Brady Cristofanini\"','1382467649','\"9705 Westport Crossing\"','bcristofaninib@vkontakte.ru',47),(13,'\"Rand Wrefford\"','1413626177','\"01267 Mendota Trail\"','rwreffordc@abc.net.au',60),(14,'\"Ase Isakowicz\"','1278830949','\"89546 Westerfield Point\"','aisakowiczd@51.la',49),(15,'\"Erhart Gammett\"','1780123519','\"758 Glacier Hill Way\"','egammette@squarespace.com',24),(16,'\"Michaella McConnachie\"','1434554159','\"76826 Gulseth Trail\"','mmcconnachief@oaic.gov.au',44),(17,'\"Sheridan Pearch\"','1024684960','\"15557 Sycamore Point\"','spearchg@hp.com',18),(18,'\"Benny Mennithorp\"','1932313239','\"77 Oakridge Alley\"','bmennithorph@usda.gov',70),(19,'\"Tremayne Chucks\"','2004428476','\"8 Arrowood Plaza\"','tchucksi@google.it',60),(20,'\"Raffarty Chaundy\"','1348167329','\"14 Ohio Trail\"','rchaundyj@va.gov',55),(21,'\"Graeme Shout\"','1158011260','\"46735 Oak Valley Way\"','gshoutk@marriott.com',27),(22,'\"Earl Brindley\"','1605536257','\"0486 Lakewood Alley\"','ebrindleyl@ucsd.edu',35),(23,'\"Zita Madelin\"','1341279021','\"15371 Hermina Place\"','zmadelinm@youtube.com',73),(24,'\"Malia Bresland\"','1551935907','\"146 Truax Junction\"','mbreslandn@deviantart.com',47),(25,'\"Rochell Balint\"','1141044712','\"88962 Erie Lane\"','rbalinto@home.pl',9),(26,'\"Kathy Goodwyn\"','1136225325','\"3786 Village Junction\"','kgoodwynp@parallels.com',22),(27,'\"Cooper Goodlife\"','1879992664','\"22 Butternut Point\"','cgoodlifeq@cam.ac.uk',74),(28,'\"Aretha Salvidge\"','1376318502','\"5196 Sullivan Place\"','asalvidger@ucla.edu',57),(29,'\"Gianina Brandom\"','1347322183','\"5 Fremont Pass\"','gbrandoms@clickbank.net',83),(30,'\"Susi Yarnton\"','1222721720','\"106 Bayside Lane\"','syarntont@bigcartel.com',96),(31,'\"Myrtle Trimble\"','1264546769','\"1523 Elgar Avenue\"','mtrimbleu@gmpg.org',69),(32,'\"Temple Kimmins\"','1941884267','\"11901 Pepper Wood Lane\"','tkimminsv@istockphoto.com',49),(33,'\"Kessia Arnaut\"','1197445528','\"832 Mccormick Drive\"','karnautw@spotify.com',65),(34,'\"Corrinne Zelley\"','2137853817','\"604 Lakewood Gardens Street\"','czelleyx@so-net.ne.jp',11),(35,'\"Roderigo Denizet\"','1005364890','\"96480 Transport Junction\"','rdenizety@deviantart.com',51),(36,'\"Abigale Beilby\"','1143842331','\"20971 Saint Paul Hill\"','abeilbyz@yale.edu',80),(37,'\"Charyl Hebborne\"','1276831903','\"869 Crowley Avenue\"','chebborne10@yandex.ru',43),(38,'\"Gaylord Attwoull\"','1105384972','\"4 Westerfield Crossing\"','gattwoull11@foxnews.com',31),(39,'\"Josi Pervew\"','1249688559','\"59215 Forster Center\"','jpervew12@gnu.org',54),(40,'\"Torry Geering\"','1595362733','\"0 Farmco Drive\"','tgeering13@storify.com',31),(41,'\"Nadean FitzGeorge\"','1353690262','\"36753 Johnson Junction\"','nfitzgeorge14@php.net',57),(42,'\"Liva Treswell\"','1301468696','\"56 Stephen Road\"','ltreswell15@paginegialle.it',31),(43,'\"Cass Linfield\"','1359502929','\"93 Center Center\"','clinfield16@abc.net.au',48),(44,'\"Barrett Ionnidis\"','1858861155','\"9568 Chinook Circle\"','bionnidis17@trellian.com',72),(45,'\"Hanna Merrigans\"','1060733987','\"3 Glacier Hill Crossing\"','hmerrigans18@reference.com',37),(46,'\"Feliza McIlherran\"','1413828590','\"955 Crownhardt Alley\"','fmcilherran19@netvibes.com',58),(47,'\"Kynthia Handrik\"','2121405608','\"9102 Dayton Plaza\"','khandrik1a@etsy.com',5),(48,'\"Sheila-kathryn Phair\"','1043901214','\"7564 Crest Line Hill\"','sphair1b@timesonline.co.uk',78),(49,'\"Stephie Kubek\"','1530024814','\"98764 Sunfield Place\"','skubek1c@vistaprint.com',87),(50,'\"Gordy Abela\"','1075174679','\"684 Milwaukee Way\"','gabela1d@drupal.org',47),(51,'\"Leanora Whyborne\"','1133228980','\"51079 Hallows Lane\"','lwhyborne1e@altervista.org',64),(52,'\"Arlen Brasener\"','1268482903','\"3858 Fremont Crossing\"','abrasener1f@ihg.com',35),(53,'\"Boone Volage\"','1066039038','\"498 Ronald Regan Avenue\"','bvolage1g@theatlantic.com',89),(54,'\"Arabele Hurd\"','1120066408','\"16508 Fulton Parkway\"','ahurd1h@vistaprint.com',35),(55,'\"Frank Tyres\"','1862478415','\"7402 Haas Crossing\"','ftyres1i@microsoft.com',2),(56,'\"Jillayne Denyagin\"','1022459781','\"4 Fremont Plaza\"','jdenyagin1j@photobucket.com',50),(57,'\"Elise Castagnet\"','1960044176','\"16 Center Center\"','ecastagnet1k@walmart.com',21),(58,'\"Oneida Hadlee\"','2129102252','\"3073 Norway Maple Point\"','ohadlee1l@booking.com',81),(59,'\"Cathee Farley\"','1813636220','\"34145 Brown Pass\"','cfarley1m@fastcompany.com',56),(60,'\"Ingemar Aslott\"','1228540286','\"02 Westend Point\"','iaslott1n@bloglines.com',15),(61,'\"Lesly Giamo\"','1385203687','\"63 Cambridge Parkway\"','lgiamo1o@bluehost.com',36),(62,'\"Penelope Danford\"','1684200791','\"95566 Banding Hill\"','pdanford1p@kickstarter.com',6),(63,'\"Waneta Churchlow\"','1185944442','\"2 Thompson Alley\"','wchurchlow1q@whitehouse.gov',10),(64,'\"Wiatt Roja\"','1927186764','\"02742 Towne Alley\"','wroja1r@themeforest.net',35),(65,'\"Chev Davenall\"','1756561405','\"89065 Fairview Plaza\"','cdavenall1s@amazon.co.jp',28),(66,'\"Jodi Viccars\"','1589670631','\"003 Trailsway Avenue\"','jviccars1t@cdc.gov',61),(68,'\"Brander Djokovic\"','1680443008','\"8453 Vahlen Point\"','bdjokovic1v@google.com.hk',97),(69,'\"Midge Brace\"','1919166948','\"19 Dunning Court\"','mbrace1w@newyorker.com',58),(70,'\"Selie Rumke\"','1226725976','\"52 Valley Edge Pass\"','srumke1x@technorati.com',54),(71,'\"Gwyn Espinas\"','1890603749','\"1672 Logan Street\"','gespinas1y@census.gov',8),(72,'\"Consuelo Lobell\"','1067967172','\"9 South Court\"','clobell1z@bloglovin.com',47),(73,'\"Leoline Seamans\"','1125605856','\"6611 Bartelt Pass\"','lseamans20@goo.ne.jp',74),(74,'\"Veronica Goodhew\"','1840125555','\"60 Corscot Center\"','vgoodhew21@cmu.edu',46),(75,'\"Gustavo O\'Looney\"','1777159061','\"21 Jenna Point\"','golooney22@netvibes.com',14),(76,'\"Patrice Lydiate\"','1819164561','\"64 Gina Way\"','plydiate23@google.pl',37),(77,'\"Silvain Gooderridge\"','1562750237','\"987 Lighthouse Bay Court\"','sgooderridge24@redcross.org',17),(78,'\"Julee Dorn\"','1457233230','\"064 Donald Court\"','jdorn25@mail.ru',97),(80,'\"Al Possel\"','2128199102','\"66 Birchwood Road\"','apossel27@jimdo.com',30),(81,'\"Mirabella Fender\"','2090470488','\"0 7th Trail\"','mfender28@reddit.com',85),(82,'\"Stafford Brand\"','1893057035','\"7 Lakewood Avenue\"','sbrand29@princeton.edu',5),(83,'\"Abby Ellerman\"','2022352582','\"33 Duke Junction\"','aellerman2a@ocn.ne.jp',46),(84,'\"Alano Robottham\"','1401473223','\"10424 Marcy Hill\"','arobottham2b@ucoz.com',1),(85,'\"Therine Vedyasov\"','1620738092','\"881 Park Meadow Lane\"','tvedyasov2c@bing.com',18),(86,'\"Fidelity Mangenot\"','1839280880','\"94 Sage Road\"','fmangenot2d@icio.us',69),(87,'\"Adam Venus\"','1954574023','\"16518 Melby Center\"','avenus2e@angelfire.com',50),(88,'\"Filbert Heddy\"','1920877821','\"10689 Katie Drive\"','fheddy2f@cbc.ca',20),(89,'\"Darin Josselson\"','1185595634','\"9 Summit Plaza\"','djosselson2g@google.pl',18),(90,'\"Tabina Laight\"','1841083783','\"54 Hansons Alley\"','tlaight2h@1und1.de',17),(91,'\"Cherish Odcroft\"','1185584665','\"8 Luster Trail\"','codcroft2i@last.fm',52),(92,'\"Jodi Halso\"','1895407066','\"65966 Reinke Trail\"','jhalso2j@gmpg.org',94),(93,'\"Hurleigh Finicj\"','1647376922','\"551 Paget Lane\"','hfinicj2k@china.com.cn',21),(94,'\"Forster Lochrie\"','1194912625','\"02138 Mosinee Avenue\"','flochrie2l@accuweather.com',2),(95,'\"Marijn MacQuist\"','1069550789','\"97 Meadow Vale Drive\"','mmacquist2m@woothemes.com',56),(96,'\"Noland Giamitti\"','1523412223','\"45144 Evergreen Lane\"','ngiamitti2n@pagesperso-orange.fr',70),(97,'\"Michelina Bartholat\"','1033128832','\"84477 Petterle Center\"','mbartholat2o@smh.com.au',71),(98,'\"Neila Reddoch\"','1755755515','\"78 Cody Place\"','nreddoch2p@w3.org',62),(99,'\"Jarret Aspden\"','1892314305','\"30 Lien Lane\"','jaspden2q@ycombinator.com',8),(100,'\"Corby Fellows\"','1142707500','\"8322 Karstens Trail\"','cfellows2r@seattletimes.com',63);
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-24 23:04:36
