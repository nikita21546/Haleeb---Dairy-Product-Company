CREATE DATABASE  IF NOT EXISTS `haleeb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `haleeb`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: haleeb
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `date_of_order` date NOT NULL,
  `status` varchar(1000) NOT NULL,
  `branch_id` int NOT NULL,
  `payment_id` int NOT NULL,
  `cust_id` int NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `c_id_idx` (`cust_id`),
  KEY `b_id_idx` (`branch_id`),
  KEY `p_id_idx` (`payment_id`),
  CONSTRAINT `b_id` FOREIGN KEY (`branch_id`) REFERENCES `location` (`branch_id`),
  CONSTRAINT `c_id` FOREIGN KEY (`cust_id`) REFERENCES `customer` (`customer_id`),
  CONSTRAINT `p_id` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (2,'2022-07-06','Delivered',14,2,14),(3,'2022-03-29','Delivered',72,3,72),(4,'2022-04-14','Delivered',77,4,77),(5,'2023-02-04','Delivered',79,5,79),(6,'2023-02-10','Delivered',92,6,92),(7,'2022-06-02','Delivered',94,7,94),(8,'2022-04-24','Delivered',50,8,50),(9,'2022-07-03','Delivered',46,9,46),(10,'2022-07-24','Delivered',69,10,69),(12,'2022-04-03','Delivered',76,12,76),(13,'2023-01-07','Delivered',66,13,66),(14,'2022-12-09','Delivered',90,14,90),(15,'2022-08-30','Delivered',21,15,21),(16,'2022-10-24','Delivered',87,16,87),(17,'2022-06-01','Delivered',24,17,24),(19,'2023-02-01','Delivered',21,19,21),(21,'2022-03-24','Delivered',1,21,1),(22,'2022-10-12','Delivered',66,22,66),(23,'2022-09-04','Delivered',74,23,74),(24,'2022-04-03','Delivered',20,24,20),(25,'2022-05-06','Delivered',2,25,2),(26,'2022-02-17','Delivered',58,26,58),(27,'2023-01-12','Delivered',28,27,28),(28,'2023-02-06','Delivered',69,28,69),(30,'2022-12-20','Delivered',74,30,74),(40,'2022-10-20','Delivered',27,40,27),(41,'2022-03-04','Delivered',28,41,28),(43,'2022-06-10','Delivered',89,43,89),(44,'2022-09-08','Delivered',89,44,89),(46,'2022-09-07','Delivered',74,46,74),(47,'2022-11-09','Delivered',47,47,47),(48,'2022-06-03','Delivered',2,48,2),(49,'2022-03-27','Delivered',66,49,66),(50,'2022-08-26','Delivered',62,50,62),(51,'2022-03-19','Delivered',72,51,72),(52,'2022-03-30','Delivered',69,52,69),(53,'2022-10-19','Delivered',90,53,90),(54,'2022-07-28','Delivered',85,54,85),(56,'2022-03-26','Delivered',16,56,16),(58,'2022-12-16','Delivered',52,58,52),(60,'2022-09-19','Delivered',65,60,65),(61,'2022-10-11','In Transit',87,61,87),(62,'2022-04-30','In Transit',68,62,68),(63,'2023-02-13','In Transit',16,63,16),(64,'2023-01-21','In Transit',40,64,40),(65,'2022-04-11','In Transit',22,65,22),(67,'2022-03-14','In Transit',79,67,79),(68,'2022-07-18','In Transit',11,68,11),(69,'2022-12-11','In Transit',45,69,45),(70,'2022-08-13','In Transit',86,70,86),(72,'2022-07-08','In Transit',85,72,85),(73,'2022-03-23','In Transit',94,73,94),(74,'2022-10-18','In Transit',78,74,78),(75,'2022-10-06','In Transit',26,75,26),(76,'2022-06-30','Cancelled',67,76,67),(77,'2022-08-22','Cancelled',45,77,45),(78,'2022-11-17','Cancelled',41,78,41),(79,'2022-11-22','Cancelled',44,79,44),(80,'2023-01-21','Cancelled',29,80,29),(81,'2022-09-09','Cancelled',77,81,77),(82,'2023-01-01','Cancelled',46,82,46),(83,'2022-09-20','Cancelled',57,83,57),(84,'2022-10-28','Cancelled',2,84,2),(85,'2022-12-18','Cancelled',66,85,66),(86,'2023-02-09','Cancelled',55,86,55),(87,'2022-06-01','Cancelled',8,87,8),(88,'2022-07-04','Cancelled',83,88,83),(90,'2022-08-02','Returned',12,90,12),(92,'2022-11-29','Returned',45,92,45),(93,'2022-09-14','Returned',17,93,17),(94,'2022-06-11','Returned',45,94,45),(95,'2023-02-11','Returned',51,95,51),(96,'2022-12-29','Returned',53,96,53),(98,'2022-05-24','Returned',45,98,45),(99,'2022-09-17','Returned',67,99,67),(100,'2022-11-18','Returned',5,100,5),(105,'2023-03-23','Delivered',1,105,1),(107,'2023-03-23','Delivered',1,107,1),(108,'2023-03-30','In Transit',1,108,1),(109,'2023-03-30','Delivered',1,109,1),(111,'2023-04-20','Delivered',1,111,1),(112,'2023-04-20','In Transit',1,112,1),(113,'2023-04-21','In Transit',1,122,2),(114,'2023-04-21','In Transit',3,123,3),(115,'2023-04-21','In Transit',3,124,3),(116,'2023-04-24','In Transit',1,125,1),(117,'2023-04-24','In Transit',1,1,2),(118,'2023-04-24','In Transit',1,1,2),(119,'2023-04-24','Returned',1,1,3),(120,'2023-04-24','Returned',1,1,3);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-24 23:04:35
