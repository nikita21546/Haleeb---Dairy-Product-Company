CREATE DATABASE  IF NOT EXISTS `haleeb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `haleeb`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: haleeb
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `mode` varchar(1000) NOT NULL,
  `amount` int NOT NULL,
  `cust_id` int NOT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `c_id_c_idx` (`cust_id`),
  CONSTRAINT `c_id_c` FOREIGN KEY (`cust_id`) REFERENCES `customer` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (1,'Credit Card',199,1),(2,'Cash',299,2),(3,'Cash',499,3),(4,'Credit Card',399,4),(5,'Cash',699,5),(6,'Credit Card',799,6),(7,'Debit Card',199,7),(8,'Debit Card',2098,8),(9,'Debit Card',1024,9),(10,'Credit Card',499,10),(11,'Credit Card',898,11),(12,'Net Banking',599,12),(13,'Net Banking',299,13),(14,'Credit Card',498,14),(15,'Net Banking',1199,15),(16,'Cash',1299,16),(17,'Credit Card',1398,17),(18,'Debit Card',598,18),(19,'Cash',499,19),(20,'Credit Card',299,20),(21,'Cash',799,21),(22,'Credit Card',2998,22),(23,'Credit Card',1598,23),(24,'Cash',1398,24),(25,'Credit Card',1498,25),(26,'Credit Card',798,26),(27,'Cash',399,27),(28,'Debit Card',999,28),(29,'Cash',1299,29),(30,'Cash',1199,30),(40,'Cash',199,40),(41,'Net Banking',299,41),(43,'Net Banking',499,43),(44,'Credit Card',599,44),(45,'Credit Card',399,45),(46,'Credit Card',499,46),(47,'Net Banking',698,47),(48,'Net Banking',899,48),(49,'Credit Card',999,49),(50,'Credit Card',298,50),(51,'Cash',1098,51),(52,'Credit Card',198,52),(53,'Cash',2699,53),(54,'Cash',1599,54),(55,'Net Banking',1498,55),(56,'Net Banking',1298,56),(57,'Cash',499,57),(58,'Net Banking',999,58),(60,'Credit Card',498,60),(61,'Credit Card',598,61),(62,'Cash',899,62),(63,'Net Banking',499,63),(64,'Cash',2398,64),(65,'Cash',588,65),(66,'Debit Card',384,66),(67,'Debit Card',492,67),(68,'Net Banking',298,68),(69,'Net Banking',1023,69),(70,'Net Banking',2384,70),(72,'Net Banking',2184,72),(73,'Net Banking',4821,73),(74,'Net Banking',321,74),(75,'Credit Card',481,75),(76,'Net Banking',983,76),(77,'Cash',1278,77),(78,'Credit Card',3198,78),(79,'Net Banking',3485,79),(80,'Net Banking',4000,80),(81,'Cash',7821,81),(82,'Credit Card',4355,82),(83,'Debit Card',1899,83),(84,'Credit Card',499,84),(85,'Cash',788,85),(86,'Net Banking',981,86),(87,'Credit Card',352,87),(88,'Credit Card',782,88),(89,'Debit Card',2154,89),(90,'Cash',783,90),(92,'Debit Card',768,92),(93,'Credit Card',783,93),(94,'Net Banking',3498,94),(95,'Net Banking',7811,95),(96,'Credit Card',2340,96),(98,'Debit Card',499,98),(99,'Net Banking',799,99),(100,'Credit Card',1599,100),(105,'Cash',1599,1),(107,'Net Banking',1598,1),(108,'Debit Card',199,1),(109,'Credit Card',599,1),(110,'Net Banking',999,1),(111,'Credit Card',399,1),(112,'Cash',3582,1),(122,'Cash',2191,2),(123,'Net Banking',2591,3),(124,'Cash',599,3),(125,'Net Banking',2093,1);
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `payment_AFTER_INSERT` AFTER INSERT ON `payment` FOR EACH ROW BEGIN
	insert into orders(date_of_order, status, branch_id, payment_id, cust_id) values (curdate(), "In Transit", NEW.cust_id, NEW.payment_id, NEW.cust_id);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-24 23:04:35
