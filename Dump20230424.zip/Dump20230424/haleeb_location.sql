CREATE DATABASE  IF NOT EXISTS `haleeb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `haleeb`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: haleeb
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location` (
  `branch_id` int NOT NULL,
  `address` varchar(100) NOT NULL,
  `ph_no` varchar(10) NOT NULL,
  PRIMARY KEY (`branch_id`),
  UNIQUE KEY `admin_id_UNIQUE` (`branch_id`),
  UNIQUE KEY `b_id_UNIQUE` (`address`),
  UNIQUE KEY `ph_no_UNIQUE` (`ph_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (1,'\"Address 1\"','1234567890'),(2,'\"Address 2\"','1234567891'),(3,'\"Address 3\"','1234567892'),(4,'\"Address 4\"','1234567893'),(5,'\"Address 5\"','1234567894'),(6,'\"Address 6\"','1234567895'),(7,'\"Address 7\"','1234567896'),(8,'\"Address 8\"','1234567897'),(9,'\"Address 9\"','1234567898'),(10,'\"Address 10\"','1234567899'),(11,'\"Address 11\"','1234567800'),(12,'\"Address 12\"','1234567801'),(13,'\"Address 13\"','1234567802'),(14,'\"Address 14\"','1234567803'),(15,'\"Address 15\"','1234567804'),(16,'\"Address 16\"','1234567805'),(17,'\"Address 17\"','1234567806'),(18,'\"Address 18\"','1234567807'),(19,'\"Address 19\"','1234567808'),(20,'\"Address 20\"','1234567809'),(21,'\"Address 21\"','1234567810'),(22,'\"Address 22\"','1234567811'),(23,'\"Address 23\"','1234567812'),(24,'\"Address 24\"','1234567813'),(25,'\"Address 25\"','1234567814'),(26,'\"Address 26\"','1234567815'),(27,'\"Address 27\"','1234567816'),(28,'\"Address 28\"','1234567817'),(29,'\"Address 29\"','1234567818'),(30,'\"Address 30\"','1234567819'),(31,'\"Address 31\"','1234567820'),(32,'\"Address 32\"','1234567821'),(33,'\"Address 33\"','1234567822'),(34,'\"Address 34\"','1234567823'),(35,'\"Address 35\"','1234567824'),(36,'\"Address 36\"','1234567825'),(37,'\"Address 37\"','1234567826'),(38,'\"Address 38\"','1234567827'),(39,'\"Address 39\"','1234567828'),(40,'\"Address 40\"','1234567829'),(41,'\"Address 41\"','1234567830'),(42,'\"Address 42\"','1234567831'),(43,'\"Address 43\"','1234567832'),(44,'\"Address 44\"','1234567833'),(45,'\"Address 45\"','1234567834'),(46,'\"Address 46\"','1234567835'),(47,'\"Address 47\"','1234567836'),(48,'\"Address 48\"','1234567837'),(49,'\"Address 49\"','1234567838'),(50,'\"Address 50\"','1234567839'),(51,'\"Address 51\"','1234567840'),(52,'\"Address 52\"','1234567841'),(53,'\"Address 53\"','1234567842'),(54,'\"Address 54\"','1234567843'),(55,'\"Address 55\"','1234567844'),(56,'\"Address 56\"','1234567845'),(57,'\"Address 57\"','1234567846'),(58,'\"Address 58\"','1234567847'),(59,'\"Address 59\"','1234567848'),(60,'\"Address 60\"','1234567849'),(61,'\"Address 61\"','1234567850'),(62,'\"Address 62\"','1234567851'),(63,'\"Address 63\"','1234567852'),(64,'\"Address 64\"','1234567853'),(65,'\"Address 65\"','1234567854'),(66,'\"Address 66\"','1234567855'),(67,'\"Address 67\"','1234567856'),(68,'\"Address 68\"','1234567857'),(69,'\"Address 69\"','1234567858'),(70,'\"Address 70\"','1234567859'),(71,'\"Address 71\"','1234567860'),(72,'\"Address 72\"','1234567861'),(73,'\"Address 73\"','1234567862'),(74,'\"Address 74\"','1234567863'),(75,'\"Address 75\"','1234567864'),(76,'\"Address 76\"','1234567865'),(77,'\"Address 77\"','1234567866'),(78,'\"Address 78\"','1234567867'),(79,'\"Address 79\"','1234567868'),(80,'\"Address 80\"','1234567869'),(81,'\"Address 81\"','1234567870'),(82,'\"Address 82\"','1234567871'),(83,'\"Address 83\"','1234567872'),(84,'\"Address 84\"','1234567873'),(85,'\"Address 85\"','1234567874'),(86,'\"Address 86\"','1234567875'),(87,'\"Address 87\"','1234567876'),(88,'\"Address 88\"','1234567877'),(89,'\"Address 89\"','1234567878'),(90,'\"Address 90\"','1234567879'),(91,'\"Address 91\"','1234567880'),(92,'\"Address 92\"','1234567881'),(93,'\"Address 93\"','1234567882'),(94,'\"Address 94\"','1234567883'),(95,'\"Address 95\"','1234567884'),(96,'\"Address 96\"','1234567885'),(97,'\"Address 97\"','1234567886'),(98,'\"Address 98\"','1234567887'),(99,'\"Address 99\"','1234567888'),(100,'Address 100','1242376212'),(199,'\"Address 100\"','123457889');
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `location_AFTER_INSERT` AFTER INSERT ON `location` FOR EACH ROW BEGIN
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 1, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 2, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 3, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 4, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 5, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 6, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 7, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 8, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 9, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 10, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 11, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 12, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 13, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 14, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 15, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 16, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 17, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 18, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 19, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 20, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 21, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 22, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 23, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 24, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 25, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 26, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 27, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 28, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 29, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 30, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 31, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 32, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 33, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 34, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 35, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 36, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 37, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 38, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 39, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 40, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 41, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 42, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 43, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 44, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 45, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 46, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 47, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 48, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 49, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 50, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 51, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 52, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 53, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 54, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 55, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 56, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 57, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 58, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 59, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 60, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 61, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 62, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 63, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 64, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 65, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 66, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 67, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 68, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 69, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 70, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 71, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 72, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 73, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 74, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 75, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 76, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 77, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 78, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 79, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 80, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 81, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 82, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 83, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 84, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 85, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 86, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 87, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 88, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 89, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 90, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 91, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 92, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 93, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 94, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 95, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 96, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 97, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 98, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 99, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 100, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 101, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 102, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 103, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 104, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 105, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 106, 50);
	insert into location_inventory (loc_id, product_id, stock) values (NEW.branch_id, 107, 50);

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-24 23:04:35
