CREATE DATABASE  IF NOT EXISTS `haleeb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `haleeb`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: haleeb
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `distributor`
--

DROP TABLE IF EXISTS `distributor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `distributor` (
  `distributor_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `ph_no` varchar(10) NOT NULL,
  `branch_no` int NOT NULL,
  PRIMARY KEY (`distributor_id`),
  UNIQUE KEY `ph_no_UNIQUE` (`ph_no`),
  UNIQUE KEY `branch_no_UNIQUE` (`branch_no`),
  CONSTRAINT `b_no` FOREIGN KEY (`branch_no`) REFERENCES `location` (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `distributor`
--

LOCK TABLES `distributor` WRITE;
/*!40000 ALTER TABLE `distributor` DISABLE KEYS */;
INSERT INTO `distributor` VALUES (1,'Heloise Shaxby','2605059055',1),(2,'Madalena De La Haye','9384116161',2),(3,'Hilly Gorey','2099514621',3),(4,'Lilly Wixon','2937724197',4),(5,'Harland Faye','5132195702',5),(6,'Ronnica Clayson','8386698753',6),(7,'Chandler Sinisbury','4798729145',7),(8,'Kori Sawood','8957114584',8),(9,'Jonathon Ruggs','6764168457',9),(10,'Boot Daybell','9389272342',10),(11,'Tessie Nassey','6331909690',11),(12,'Damaris Letterick','6943311170',12),(13,'Kathi Beeck','6787641824',13),(14,'Orlando Ummfrey','2259743751',14),(15,'Shani Gingedale','9888167732',15),(16,'Ralina O\'Mohun','6645979047',16),(17,'Myrtia Kilbane','2486535626',17),(18,'Ad Glanz','2797404452',18),(19,'Pamelina Peake','8057881346',19),(20,'Joela Greste','5529773900',20),(21,'Laughton Dalligan','3016902605',21),(22,'Udell Clotworthy','9018771050',22),(23,'Cindee Studdard','7273681579',23),(24,'April Byrd','6966993878',24),(25,'Teddie Shrimpling','7621247469',25),(26,'Gilberta Vinter','2725139820',26),(27,'Haze Kleanthous','5486713563',27),(28,'Justis Pembridge','9074651030',28),(29,'Orel Falconar','7404423659',29),(30,'Clayson Abbet','5341404435',30),(31,'Ev Bagehot','6584747006',31),(32,'Brittney Marcussen','5684889393',32),(33,'Tallia Quant','6034297099',33),(34,'Carole Trimbey','4626952538',34),(35,'Murial Chadbourne','7685240919',35),(36,'Emelia Krzyzowski','1521094242',36),(37,'Ramona Flux','8091578045',37),(38,'Shaine Dalling','9084090864',38),(39,'Jimmie Tomblin','2068694421',39),(40,'Sibyl Challes','4663533908',40),(41,'Myriam Benoey','3422450653',41),(42,'Fernande Mollett','4726036454',42),(43,'Daisey Hartington','3122908392',43),(44,'Homer Deason','9554996293',44),(45,'Georgeanne Caistor','5022567930',45),(46,'Brittany McArte','2516578700',46),(47,'Baily Copestake','8033899622',47),(48,'Rosabelle Hoff','2077685142',48),(49,'Vasily Giovanazzi','2479729978',49),(50,'Jeffie Pesic','7674753310',50),(51,'Kamillah Jepperson','5602772477',51),(52,'Hendrik Uppett','6681077655',52),(53,'Read Tieraney','4059929586',53),(54,'Olly MacNally','7156873167',54),(55,'Dorothy Andrich','8444708725',55),(56,'Miles Coode','3418843165',56),(57,'Marylinda Dermot','2542627501',57),(58,'Maxim Ferronel','5879347008',58),(59,'Emmalee Malicki','2732498164',59),(60,'Briana Kelemen','3694585135',60),(61,'Anica Lapenna','9922565380',61),(62,'Danni Clemett','9404915121',62),(63,'Tessa Treen','9154125338',63),(64,'Sile Klimus','2065530621',64),(65,'Anderson Gebb','9095499167',65),(66,'Oona Cossar','3986164104',66),(67,'Dionisio Maple','4729153857',67),(68,'Trina Grimwood','1623771595',68),(69,'Gene Futty','5042841606',69),(70,'Alene Binion','3501092884',70),(71,'Danny Gibbins','2053880353',71),(72,'Karlen Kliemke','7139311545',72),(73,'Pavia Chidwick','5758177638',73),(74,'Sherline Maier','1668906618',74),(75,'Artus Billett','2767191723',75),(76,'Artemas Delmage','8924510551',76),(77,'Zachariah Cicconetti','4821889197',77),(78,'Elnora Biggs','6306660748',78),(79,'Paolo Bortolozzi','3052032255',79),(80,'Dagny MacDwyer','5871417339',80),(81,'Katie Beckenham','1046509690',81),(82,'Pansie Dobel','8717020422',82),(83,'Pauletta Hassur','5922524902',83),(84,'Adina Acheson','8358837112',84),(85,'Amelina Naish','8298043548',85),(86,'Theo Bradbury','2749986293',86),(87,'Teressa Yannikov','2598891866',87),(88,'Prisca Keavy','4989595141',88),(89,'Bertina Dosdale','2127405038',89),(90,'Annamarie Choudhury','7934664675',90),(91,'Domini Pregel','9386210336',91),(92,'Edithe Treneer','2015362430',92),(93,'Urbanus Godbald','7282215280',93),(94,'Mada Harlick','5563776014',94),(95,'Luigi Thirwell','6703751715',95),(96,'Hope Davidi','6333631113',96),(97,'Maureene Pauwel','6455962340',97),(98,'Dmitri Espada','4913926880',98),(99,'Linnell Rivallant','2045162014',99);
/*!40000 ALTER TABLE `distributor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-24 23:04:36
